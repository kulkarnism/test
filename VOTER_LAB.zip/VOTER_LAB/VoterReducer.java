package Voter;

import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import java.io.IOException;


public class VoterReducer  extends Reducer <Text,IntWritable,Text,FloatWritable> {


}
