#!/bin/bash

USER=`whoami`

export HADOOP_HOME=/opt/mapr/hadoop/hadoop-0.20.2
export LD_LIBRARY_PATH=$HADOOP_HOME/lib/native/Linux-amd64-64
export CLASSPATH=$HADOOP_HOME/lib/*:$HADOOP_HOME/*:/user/$USER/5/VOTER_LAB/*
export HADOOP_CLASSPATH=$CLASSPATH

javac -d classes VoterMapper.java
javac -d classes VoterReducer.java
jar -cvf Voter.jar -C classes/ .
javac -classpath $CLASSPATH:Voter.jar -d classes VoterDriver.java
jar -cvf Voter.jar -C classes/ .
javac -classpath $CLASSPATH:Voter.jar -d classes VoterTest.java
jar -cvf Voter.jar -C classes/ .
