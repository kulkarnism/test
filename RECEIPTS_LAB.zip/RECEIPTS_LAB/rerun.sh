#!/bin/bash

export HADOOP_HOME=/opt/mapr/hadoop/hadoop-0.20.2
export LD_LIBRARY_PATH=$HADOOP_HOME/lib/native/Linux-amd64-64
export CLASSPATH=$HADOOP_HOME/lib/*:$HADOOP_HOME/*
export HADOOP_CLASSPATH=$CLASSPATH

USER=`whoami`

rm -rf /user/$USER/RECEIPTS_LAB/OUT
hadoop jar Receipts.jar Receipts.ReceiptsDriver /user/$USER/RECEIPTS_LAB/DATA/receipts.txt /user/$USER/RECEIPTS_LAB/OUT 
