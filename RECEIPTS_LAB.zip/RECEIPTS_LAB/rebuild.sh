#!/bin/bash

export HADOOP_HOME=/opt/mapr/hadoop/hadoop-0.20.2
export LD_LIBRARY_PATH=$HADOOP_HOME/lib/native/Linux-amd64-64
export CLASSPATH=$HADOOP_HOME/*:$HADOOP_HOME/lib/* 
export HADOOP_CLASSPATH=$CLASSPATH

javac -d classes ReceiptsMapper.java
javac -d classes ReceiptsReducer.java
jar -cvf Receipts.jar -C classes/ .
javac -classpath $CLASSPATH:Receipts.jar -d classes ReceiptsDriver.java
jar -uvf Receipts.jar -C classes/ .
